<!--footer-->
    <div class="footer">
       <p>&copy; 2024 PAULA Admin Panel.</p>
    </div>
        <!--//footer-->